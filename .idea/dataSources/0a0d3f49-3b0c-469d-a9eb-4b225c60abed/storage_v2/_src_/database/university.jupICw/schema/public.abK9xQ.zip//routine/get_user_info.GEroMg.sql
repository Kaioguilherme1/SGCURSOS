create function get_user_info()
    returns TABLE(user_name character varying, created_date date, created_time time without time zone)
    language plpgsql
as
$$
      BEGIN
        RETURN QUERY
          SELECT name AS user_name, "createdAt"::date, "createdAt"::time
          FROM "Users";
      END;
      $$;

alter function get_user_info() owner to postgres;

